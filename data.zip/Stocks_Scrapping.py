import requests
from bs4 import BeautifulSoup

url='https://www.screener.in/screens/381166/stocks-to-watch/'
res = requests.get(url)
# print(res)

soup=BeautifulSoup(res.text,features='html.parser')
# print(soup) 
soup.prettify()
title=soup.title
# print(title.text)

stocks_data=soup.find('table') 
# print(stocks_data)

cont=stocks_data.find('tbody')

rows=cont.find_all('tr')
# print(rows) 

info=[]
for i in rows:
    cols=i.find_all("td")
    stock_info=[j.text for j in cols]
    info.append(stock_info)
info.pop(0)
info.pop(15)
# print(info)

Sr_No=[]
for i in info:
    serial=i[0]
    serial=serial[0:-1]
    serial=int(serial)
    Sr_No.append(serial)
# print(Sr_No)
# print(type(Sr_No))

Name=[]
for i in info:
    names=i[1]
    names=names[1:-1]
    Name.append(names)
# print(Name)

cmp=[]
for i in info:
    cmp_float=i[2]
    cmp_float=float(cmp_float)
    cmp.append(cmp_float)
# print(cmp)

pe=[]
for i in info:
    pe_float=i[3]
    pe_float=float(pe_float)
    pe.append(pe_float)
# print(pe)

mar_cap=[]
for i in info:
    mar_cap_float=i[4]
    mar_cap_float=float(mar_cap_float)
    mar_cap.append(mar_cap_float)
# print(mar_cap)

div_yld=[]
for i in info:
    div_yld_float=i[5]
    div_yld_float=float(div_yld_float)
    div_yld.append(div_yld_float)
# print(div_yld)

np_qtr=[]
for i in info:
    np_qtr_float=i[6]
    np_qtr_float=float(np_qtr_float)
    np_qtr.append(np_qtr_float)
# print(np_qtr)

qtr_profit=[]
for i in info:
    qtr_profit_float=i[7]
    qtr_profit_float=float(qtr_profit_float)
    qtr_profit.append(qtr_profit_float)
# print(qtr_profit)

sales_qtr=[]
for i in info:
    sales_qtr_float=i[8]
    sales_qtr_float=float(sales_qtr_float)
    sales_qtr.append(sales_qtr_float)
# print(sales_qtr)

qtr_sales=[]
for i in info:
    qtr_sales_float=i[9]
    qtr_sales_float=float(qtr_sales_float)
    qtr_sales.append(qtr_sales_float)
# print(qtr_sales)

roce=[]
for i in info:
    roce_float=i[10]
    roce_float=float(roce_float)
    roce.append(roce_float)
# print(roce)

yrs_pe=[]
for i in info:
    yrs_pe_float=i[11]
    yrs_pe_float=float(yrs_pe_float)
    yrs_pe.append(yrs_pe_float)
# print(yrs_pe)

stocks_data={
    "Sr No.": Sr_No,
    "Name": Name,
    "Current Market Price(Rs.)": cmp, 
    "Price to Earning": pe,
    "Market Capitalization(Rs.Cr.)": mar_cap,
    "Dinidend Yield(%)": div_yld,
    "Net Profit Latest Quarter(Rs.Cr.)": np_qtr,
    "Quarterly Profit Growth(%)": qtr_profit,
    "Sales Latest Quarter(Rs.Cr.)": sales_qtr,
    "Quarterly Sales Growth(%)": qtr_sales,
    "Return on Capital Employed(%)": roce,
    "Historical Price to Earning(10 Years)": yrs_pe
}

# print(stocks_data)


import pandas as pd

df=pd.DataFrame(stocks_data)
df=df.iloc[:,1:]
# print(df)
df.to_csv("Stocks Scrapping.csv")